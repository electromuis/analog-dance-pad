#pragma once

#include "USBHID.h"

#define INPUT_REPORT_ID                  0x1
#define PAD_CONFIGURATION_REPORT_ID      0x2
#define RESET_REPORT_ID                  0x3
#define SAVE_CONFIGURATION_REPORT_ID     0x4
#define NAME_REPORT_ID                   0x5
#define UNUSED_ANALOG_JOYSTICK_REPORT_ID 0x6
#define LIGHT_RULE_REPORT_ID             0x7
#define FACTORY_RESET_REPORT_ID          0x8
#define IDENTIFICATION_REPORT_ID         0x9
#define LED_MAPPING_REPORT_ID            0xA
#define SET_PROPERTY_REPORT_ID           0xB
#define SENSOR_REPORT_ID      			 0xC
#define DEBUG_REPORT_ID      	         0xD
#define IDENTIFICATION_V2_REPORT_ID      0xE
#define LIGHTS_REPORT_ID                 0xF

class USBAdp: public USBHIDDevice {
private:
    USBHID hid;
public:
    USBAdp(void);
    void begin(void);
    void end(void);

    // internal use
    uint16_t _onGetDescriptor(uint8_t* buffer);
    virtual uint16_t _onGetFeature(uint8_t report_id, uint8_t* buffer, uint16_t len);
};

void ModuleUSBInit();