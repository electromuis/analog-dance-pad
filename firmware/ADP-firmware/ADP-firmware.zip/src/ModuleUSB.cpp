#include "ModuleUSB.hpp"
#include "USB.h"
#include "DancePadConfig.h"
#include "Reports/PadReports.h"

USBAdp usbHandle;

static const uint8_t report_descriptor[] = {
    HID_USAGE_PAGE(HID_USAGE_PAGE_DESKTOP),
    HID_USAGE(HID_USAGE_DESKTOP_JOYSTICK),
    HID_COLLECTION(HID_COLLECTION_APPLICATION),

        HID_REPORT_ID(INPUT_REPORT_ID)
        HID_USAGE_PAGE(HID_USAGE_PAGE_BUTTON),
        HID_USAGE_MIN(0x01),
        HID_USAGE_MAX(BUTTON_COUNT),
        HID_LOGICAL_MIN(0x00),
        HID_LOGICAL_MAX(0x01),
        HID_REPORT_SIZE(0x01),
        HID_REPORT_COUNT(BUTTON_COUNT),
        HID_INPUT(HID_DATA | HID_VARIABLE | HID_ABSOLUTE),

        HID_USAGE_PAGE_N(HID_USAGE_PAGE_VENDOR, 2),
        HID_USAGE(HID_USAGE_DESKTOP_POINTER),
        HID_COLLECTION(HID_COLLECTION_PHYSICAL),
            HID_USAGE(HID_USAGE_DESKTOP_POINTER),
            HID_LOGICAL_MIN(0x00),
            HID_LOGICAL_MAX(0xFF),
            HID_REPORT_SIZE(0x08),
            HID_REPORT_COUNT(SENSOR_COUNT * 2),
            HID_INPUT(HID_DATA | HID_VARIABLE | HID_ABSOLUTE),
        HID_COLLECTION_END,

        HID_REPORT_ID(NAME_REPORT_ID)
        HID_USAGE_PAGE_N(HID_USAGE_PAGE_VENDOR, 2),
        HID_USAGE(HID_USAGE_DESKTOP_MOUSE),
        HID_COLLECTION(HID_COLLECTION_PHYSICAL),
            HID_USAGE(HID_USAGE_DESKTOP_MOUSE),
            HID_LOGICAL_MIN(0x00),
            HID_LOGICAL_MAX(0xFF),
            HID_REPORT_SIZE(0x08),
            HID_REPORT_COUNT(sizeof(NameFeatureHIDReport)),
            HID_FEATURE(HID_DATA | HID_VARIABLE | HID_ABSOLUTE | HID_NON_VOLATILE),
        HID_COLLECTION_END,

        HID_REPORT_ID(IDENTIFICATION_REPORT_ID)
        HID_USAGE_PAGE_N(HID_USAGE_PAGE_VENDOR, 2),
        HID_USAGE(HID_USAGE_DESKTOP_MOUSE),
        HID_COLLECTION(HID_COLLECTION_PHYSICAL),
            HID_USAGE(HID_USAGE_DESKTOP_MOUSE),
            HID_LOGICAL_MIN(0x00),
            HID_LOGICAL_MAX(0xFF),
            HID_REPORT_SIZE(0x08),
            HID_REPORT_COUNT(sizeof(IdentificationFeatureReport)),
            HID_FEATURE(HID_DATA | HID_VARIABLE | HID_ABSOLUTE | HID_NON_VOLATILE),
        HID_COLLECTION_END,

        HID_REPORT_ID(IDENTIFICATION_V2_REPORT_ID)
        HID_USAGE_PAGE_N(HID_USAGE_PAGE_VENDOR, 2),
        HID_USAGE(HID_USAGE_DESKTOP_MOUSE),
        HID_COLLECTION(HID_COLLECTION_PHYSICAL),
            HID_USAGE(HID_USAGE_DESKTOP_MOUSE),
            HID_LOGICAL_MIN(0x00),
            HID_LOGICAL_MAX(0xFF),
            HID_REPORT_SIZE(0x08),
            HID_REPORT_COUNT(sizeof(IdentificationV2FeatureReport)),
            HID_FEATURE(HID_DATA | HID_VARIABLE | HID_ABSOLUTE | HID_NON_VOLATILE),
        HID_COLLECTION_END,

    HID_COLLECTION_END
};

void ModuleUSBInit()
{
    usbHandle.begin();

    USB.VID(0x1209);
    USB.VID(0x1209);
    USB.PID(0xB196);
    USB.manufacturerName("DDR-EXP");
    USB.productName("FSR Mini pad");

    USB.begin();
}

USBAdp::USBAdp()
{
    static bool initialized = false;

    if(!initialized){
        initialized = true;
        hid.addDevice(this, sizeof(report_descriptor));
    }
}

void USBAdp::begin()
{
    hid.begin();
}

void USBAdp::end()
{

}

uint16_t USBAdp::_onGetDescriptor(uint8_t* dst)
{
    memcpy(dst, report_descriptor, sizeof(report_descriptor));
    return sizeof(report_descriptor);
}

uint16_t USBAdp::_onGetFeature(uint8_t report_id, uint8_t* buffer, uint16_t len)
{
    if(report_id == NAME_REPORT_ID) {
        //if(sizeof(NameFeatureHIDReport) != len)
        //    return 0;
        NameFeatureHIDReport* reportPtr = (NameFeatureHIDReport*)buffer;
        *reportPtr = NameFeatureHIDReport();
        return sizeof(NameFeatureHIDReport);
    }

    if(report_id == IDENTIFICATION_REPORT_ID) {
        IdentificationFeatureReport* reportPtr = (IdentificationFeatureReport*)buffer;
        *reportPtr = IdentificationFeatureReport();
        return sizeof(IdentificationFeatureReport);
    }

    if(report_id == IDENTIFICATION_V2_REPORT_ID) {
        IdentificationV2FeatureReport* reportPtr = (IdentificationV2FeatureReport*)buffer;
        *reportPtr = IdentificationV2FeatureReport();
        return sizeof(IdentificationV2FeatureReport);
    }

    //if(report_id == INPUT_REPORT_ID) {
        //if(sizeof(InputHIDReport) != len)
        //    return 0;
        InputHIDReport* reportPtr = (InputHIDReport*)buffer;
        *reportPtr = InputHIDReport();
        return sizeof(InputHIDReport);
    //}
}