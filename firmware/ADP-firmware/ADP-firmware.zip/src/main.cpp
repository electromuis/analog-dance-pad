#include <Arduino.h>
#include "ModuleUSB.hpp"

void setup() {
  ModuleUSBInit();
}

void loop() {
  // put your main code here, to run repeatedly:
}